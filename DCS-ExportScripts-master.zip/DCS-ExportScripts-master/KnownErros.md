# Known errors are listed here.
---
Please do not complain about the mistakes, but find a solution.
---

On all Flaming Cliffs aircraft there are problems with the display of various instruments or warning lights.

E.g. 
- Many data of the functions LoGetEngineInfo(), LoGetMCPState(), ...
- In the A-10A / F-15C, there are differences between the metric return values of the LoGetAltitudeAboveSeaLevel(), LoGetAltitudeAboveGroundLevel(), LoGetTrueAirSpeed(), ..., and the converted values values.
