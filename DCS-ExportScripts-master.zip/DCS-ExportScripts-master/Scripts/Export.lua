
-- load the DCS ExportScript for DAC and Ikarus
dofile(lfs.writedir()..[[Scripts\DCS-ExportScript\ExportScript.lua]])
